package com.zensar.jobcentral.services;

import com.zensar.jobcentral.entities.JobSeekerPersonal;

public interface JobSeekerPersonalService {
	void add(JobSeekerPersonal product);
    void update(JobSeekerPersonal product);
    void remove(JobSeekerPersonal product);
    
}
