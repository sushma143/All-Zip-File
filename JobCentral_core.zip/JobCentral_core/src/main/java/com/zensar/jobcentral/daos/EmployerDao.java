package com.zensar.jobcentral.daos;

import java.util.List;

import com.zensar.jobcentral.entities.Employer;

public interface EmployerDao {
	List<Employer> getAll();
	Employer getById(int userId);
	void insert(Employer employer);
	void update(Employer employer) ;
	void delete(Employer employer);
}
