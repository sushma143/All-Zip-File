package com.zensar.jobcentral.daos;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.zensar.jobcentral.entities.JobSeekerPersonal;



public class JobSeekerPersonalImpl implements JobSeekerPersonalDao {
	
	private Session session;
	
	public JobSeekerPersonalImpl() {
		// TODO Auto-generated constructor stub
		Configuration c=new Configuration().configure();
		SessionFactory f= c.buildSessionFactory();
		session=f.openSession();
	}

	@Override
	public void insert(JobSeekerPersonal jobSeeker) {
		// TODO Auto-generated method stub
		Transaction t=session.beginTransaction();
		session.save( jobSeeker);
		t.commit();
	}

	@Override
	public void update(JobSeekerPersonal jobSeeker) {
		// TODO Auto-generated method stub
		Transaction t=session.beginTransaction();
		session.update( jobSeeker);
		t.commit();
	}

	@Override
	public void delete(JobSeekerPersonal jobSeeker) {
		// TODO Auto-generated method stub
		Transaction t=session.beginTransaction();
		session.delete( jobSeeker);
		t.commit();
	}

}
