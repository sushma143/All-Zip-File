package com.zensar.jobcentral.entities;

import java.sql.Blob;
import java.util.Date;

public class JobSeekerPersonal {
	private int jobSeekerId;
	private String name;
	private Date dob;
	private int locationId;
	private Blob resume;
	private String designation;
	private long mob;
	
	public JobSeekerPersonal() {
		// TODO Auto-generated constructor stub
	}
	
	public int getJobSeekerId() {
		return jobSeekerId;
	}
	public void setJobSeekerId(int jobSeekerId) {
		this.jobSeekerId = jobSeekerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public Blob getResume() {
		return resume;
	}
	public void setResume(Blob resume) {
		this.resume = resume;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}

	public JobSeekerPersonal(int jobSeekerId, String name, Date dob, int locationId, Blob resume, String designation,
			long mob) {
		super();
		this.jobSeekerId = jobSeekerId;
		this.name = name;
		this.dob = dob;
		this.locationId = locationId;
		this.resume = resume;
		this.designation = designation;
		this.mob = mob;
	}
	
	

}
