package com.zensar.jobcentral.services;


import com.zensar.jobcentral.daos.JobSeekerPersonalDao;
import com.zensar.jobcentral.daos.JobSeekerPersonalImpl;
import com.zensar.jobcentral.entities.JobSeekerPersonal;


public class JobSeekerPersonalServiceImpl implements JobSeekerPersonalService {

	private JobSeekerPersonalDao JobSeekerPersonalDao; 
	
	public JobSeekerPersonalServiceImpl() {
		// TODO Auto-generated constructor stub

		JobSeekerPersonalDao=new JobSeekerPersonalImpl();

	}
		
	@Override
	public void add(JobSeekerPersonal product) {
		// TODO Auto-generated method stub
		JobSeekerPersonalDao.insert(product);

		
	}

	@Override
	public void update(JobSeekerPersonal product) {
		// TODO Auto-generated method stub
		JobSeekerPersonalDao.update(product);

	}

	@Override
	public void remove(JobSeekerPersonal product) {
		// TODO Auto-generated method stub
		JobSeekerPersonalDao.delete(product);

		
	}

	

}
