package com.zensar.jobcentral.entities;

/**
 * @author Gourab Sarkar
 * @modification_date 07 Oct 2019 18:57
 * @creation_date 01 Oct 2019 21:02
 * @version 0.1
 * @copyright Zensar Technologies 2019. All Rights Reserved.
 * @description This is the persistent JobSeeker Class (operates in Persistence layer)
 */

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class JobSeeker {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int jobSeekerId;
	
	@OneToOne
	@JoinColumn(name = "userId")
	private Login login;
	
	@Column(nullable = false, updatable = true)
	private String name;
	@Column(nullable = false, updatable = true)
	private int dob;
	@Column(unique = true , nullable = false, updatable = true)
	private int mobile;
//	@Column(nullable = false, updatable = true)
//	private int locationId;
	
	@OneToOne
	@JoinColumn(name = "locationId")
	private Location location;
	
	private int sscYear;
	private double sscPercent;
	private int hscYear;
	private double hscPercent;
	@Column(nullable = false, updatable = true)
	private String qualification;
	@Column(nullable = false, updatable = true)
	private int qualificationYear;
	@Column(nullable = false, updatable = true)
	private double cgpa;
	@Column(nullable = false, updatable = true)
	private String summary;
	private String lastRole;
	private int fromDateLastRole;
	private int toDateLastRole;
	@Column(nullable = false, updatable = true)
	private String skillset;
	@Column(nullable = false, updatable = true)
	private Blob resume;
	
	@OneToMany(mappedBy = "jobSeeker")
	@JoinColumn(name = "userId")
	private Job jobs;
	
	@OneToMany(mappedBy = "jobSeeker")
	@JoinColumn(name = "userId")
	private JobApplications jobApplications;

	public int getJobSeekerId() {
		return jobSeekerId;
	}

	public void setJobSeekerId(int jobSeekerId) {
		this.jobSeekerId = jobSeekerId;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDob() {
		return dob;
	}

	public void setDob(int dob) {
		this.dob = dob;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}	

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public int getSscYear() {
		return sscYear;
	}

	public void setSscYear(int sscYear) {
		this.sscYear = sscYear;
	}

	public double getSscPercent() {
		return sscPercent;
	}

	public void setSscPercent(double sscPercent) {
		this.sscPercent = sscPercent;
	}

	public int getHscYear() {
		return hscYear;
	}

	public void setHscYear(int hscYear) {
		this.hscYear = hscYear;
	}

	public double getHscPercent() {
		return hscPercent;
	}

	public void setHscPercent(double hscPercent) {
		this.hscPercent = hscPercent;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public int getQualificationYear() {
		return qualificationYear;
	}

	public void setQualificationYear(int qualificationYear) {
		this.qualificationYear = qualificationYear;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getLastRole() {
		return lastRole;
	}

	public void setLastRole(String lastRole) {
		this.lastRole = lastRole;
	}

	public int getFromDateLastRole() {
		return fromDateLastRole;
	}

	public void setFromDateLastRole(int fromDateLastRole) {
		this.fromDateLastRole = fromDateLastRole;
	}

	public int getToDateLastRole() {
		return toDateLastRole;
	}

	public void setToDateLastRole(int toDateLastRole) {
		this.toDateLastRole = toDateLastRole;
	}

	public String getSkillset() {
		return skillset;
	}

	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}

	public Blob getResume() {
		return resume;
	}

	public void setResume(Blob resume) {
		this.resume = resume;
	}

	public Job getJobs() {
		return jobs;
	}

	public void setJobs(Job jobs) {
		this.jobs = jobs;
	}

	public JobApplications getJobApplications() {
		return jobApplications;
	}

	public void setJobApplications(JobApplications jobApplications) {
		this.jobApplications = jobApplications;
	}

	@Override
	public String toString() {
		return "JobSeeker [jobSeekerId=" + jobSeekerId + ", login=" + login + ", name=" + name + ", dob=" + dob
				+ ", mobile=" + mobile + ", location=" + location + ", sscYear=" + sscYear + ", sscPercent="
				+ sscPercent + ", hscYear=" + hscYear + ", hscPercent=" + hscPercent + ", qualification="
				+ qualification + ", qualificationYear=" + qualificationYear + ", cgpa=" + cgpa + ", summary=" + summary
				+ ", lastRole=" + lastRole + ", fromDateLastRole=" + fromDateLastRole + ", toDateLastRole="
				+ toDateLastRole + ", skillset=" + skillset + ", resume=" + resume + ", jobs=" + jobs
				+ ", jobApplications=" + jobApplications + "]";
	}
	
}
