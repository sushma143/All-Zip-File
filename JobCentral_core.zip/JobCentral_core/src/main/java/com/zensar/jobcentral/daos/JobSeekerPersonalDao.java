package com.zensar.jobcentral.daos;

import com.zensar.jobcentral.entities.JobSeekerPersonal;

public interface JobSeekerPersonalDao {
	void insert(JobSeekerPersonal jobSeeker);
	void update(JobSeekerPersonal jobSeeker);
	void delete(JobSeekerPersonal jobSeeker);

}
