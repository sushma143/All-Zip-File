package com.zensar.jobcentral.services;

import com.zensar.jobcentral.daos.JobSeekerDao;
import com.zensar.jobcentral.entities.Login;

public class JobSeekerServiceImpl implements JobSeekerService {

	public void setJobSeekerDao(JobSeekerDao jobSeekerDao) 
	{
		// TODO This is a WIP
		// Generated to maintain syntax correctness across source code.
	}

	@Override
	public boolean validateUser(Login loginAuth) {
		return false;
		// TODO Auto-generated method stub
	}

}
