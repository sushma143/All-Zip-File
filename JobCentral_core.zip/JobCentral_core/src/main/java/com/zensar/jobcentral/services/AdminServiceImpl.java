package com.zensar.jobcentral.services;

import com.zensar.jobcentral.daos.AdminDao;
import com.zensar.jobcentral.entities.Login;

public class AdminServiceImpl implements AdminService {

	@Override
	public void setAdminDao(AdminDao adminDao) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateUser(Login loginAuth) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
